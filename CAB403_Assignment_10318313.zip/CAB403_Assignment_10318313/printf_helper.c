#include <stdio.h> 
#include <stdlib.h> 

void printf_c(){
    
}